import React from 'react';
import ReactDOM from 'react-dom';
//import App from './App';
import './index.css';
const LetterState = {
  FOUND: 'found',
  DEAD: 'dead',
  OPEN: 'open'
}

function Square(props) {
  var color;
  if (props.letterState === LetterState.OPEN) {
    color = "letter-open";
  } else if (props.letterState === LetterState.FOUND) {
    color = "letter-found";
  } else {
    color = "letter-dead";
  }
  return (
    <button className={color} onClick={props.onClick}>
      {props.value}
    </button>
  );
}



/*
function InputBox(props) {
  return (
  <div>
      <input type="text" name='GuessBox'></input>
      <input type="submit" value="Submit"></input>
      </div>
  )
}
 */
class Board extends React.Component {
  renderSquare(i) {
    return <Square
      key={i}
      value={this.props.squares[i]}
      letterState={this.props.letterState[i]}
      onClick={() => this.props.onClick(i)} />;
  }

  renderSquares() {
    var temp = []
    for (var i = 0; i < 26; i++) {
      temp.push(this.renderSquare(i))
    }
    return temp;
  }

  render() {
    return (
      <div id="daddy" className="board-row">
        {this.renderSquares()}
      </div>
    );
  }
}

class Game extends React.Component {
  constructor(props) {
    super(props);
    this.handleGuess = this.handleGuess.bind(this);
    this.state = {
      guesses: [],
      letterState: Array(26).fill(LetterState.OPEN),

      squares: Array(26).fill(1).map((_, i) => String.fromCharCode(65 + i)),
      goodLetter: [],
      badLetter: [],
      stepNumber: 0,
      secret: "peebo"
    };

  }

  calculateWinner(current) {
     /*if (this.state.secret === current.guesses) {
     let status;
      status = "Winner: ";// + this.winner;
      return true;
    } else {
      status = "Current Known letters"; // + letters.splice()
      */return false;

  }

 /* InputBox() {
    console.log("my cock is inverted");
    return (
      <form id='guessBox' onSubmit={this.handleGuess}>
        Guess a 5 Letter Word: <input type="text" name='GuessBox'></input>
        <input type="submit" value="Submit"></input>
      </form>
    )
  }*/

  handleGuess(guess) {
    console.log("mre pls");
    var guesses = this.state.guesses.slice();
    guesses.push(guess.target[0].value);
    console.log(guess.target[0].value + "guess");
    this.setState({
      guesses: guesses
    });
    console.log("no mre");
  }

  handleClick(i) {
    var ls = this.state.letterState.slice();
    if (ls[i] === LetterState.OPEN) {
      ls[i] = LetterState.FOUND;
    } else if (ls[i] === LetterState.FOUND) {
      ls[i] = LetterState.DEAD;
    } else {
      ls[i] = LetterState.OPEN;
    }
    var bad = [];
    var good = [];
    for (var j = 0; j < 26; j++) {
      if (ls[j] === LetterState.FOUND)
        good.push(String.fromCharCode(65 + j))
      else if (ls[j] === LetterState.DEAD) {
        bad.push(String.fromCharCode(65 + j))
      }
    }
    console.log("my cock is huge");
    this.setState({
      letterState: ls,
      goodLetter: good,
      badLetter: bad
    });
  }


  render() {
    const guesses = this.state.guesses;
    //const history = this.state.history;
    //const current = history[this.state.stepNumber];
    //const winner = this.calculateWinner(current.guesses);
    //const letters =  //check array of letters for green squares
    /* const moves = history.map((step, move) => {
       const desc = move ?
         'Go to move #' + move :
         'Go to game start';*/
    /*  return (
        <li key={move}>
          <button onClick={() => this.jumpTo(move)}>{desc}</button>
        </li>
      );*/
var ib = <form id='guessBox' onSubmit={this.handleGuess}>
Guess a 5 Letter Word: <input type="text" name='GuessBox'></input>
<input type="submit" value="Submit"></input>
</form>;
    return (
      <div className="game">
        <div className="game-board">
          <Board
            squares={this.state.squares}
            letterState={this.state.letterState}
            onClick={(i) => this.handleClick(i)}
          />

          <div className="game-info">
            <div>{ib} </div>
            <div>
              <ul>{guesses}</ul>
            </div>
          </div>

        </div>
      </div>
    );
  }
}

ReactDOM.render(
  <Game />,
  document.getElementById('root')
);
